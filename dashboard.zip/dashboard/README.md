# Dashboard

A Pen created on CodePen.io. Original URL: [https://codepen.io/washaweb/pen/yaBbRY](https://codepen.io/washaweb/pen/yaBbRY).

Another dashboard created with a slightly more flat approach. With a simple jQuery-UI sortable interaction on the widgets.